﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace testPraktika
{
    /// <summary>
    /// Логика взаимодействия для WindowRedakt.xaml
    /// </summary>
    public partial class WindowRedakt : Window
    {
        private string connectionString = "Server = HOME-PC\\SQLEXPRESS01; DataBase = TestBase; Trusted_Connection = True";
        public WindowRedakt()
        {
            InitializeComponent();
            LoadData();
        }

        private void btn_mainMenu_Click(object sender, RoutedEventArgs e)
        {
            MainWindow nazad = new MainWindow();
            nazad.Show();
            this.Close();
        }

        private void btn_redakt_Click(object sender, RoutedEventArgs e)
        {
            int id;
            if (int.TryParse(txt_ID.Text, out id))
            {
                string newValue = txt_Value.Text;
                UpdateRecord(id, newValue);
            }
            else
            {
                MessageBox.Show("Введите корректный ID.");
            }
        }
        private void UpdateRecord(int id, string newValue)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "UPDATE Product_Type SET [Коэффициент типа продукции] = @newValue WHERE Id = @id";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@newValue", newValue);
                command.Parameters.AddWithValue("@id", id);

                try
                {
                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        LoadData();
                        MessageBox.Show("Запись успешно обновлена.");
                    }
                    else
                    {
                        MessageBox.Show("Запись не найдена.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }
        }
        private void LoadData()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT * FROM Product_Type", connection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);
                    dataGrid.ItemsSource = dataTable.DefaultView;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Ошибка: " + ex.Message);
                }
            }
        }
    }
}
